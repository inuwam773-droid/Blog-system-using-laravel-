export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high';
  completed: boolean;
  createdAt: Date;
}

export type SnackbarMessage = {
  message: string;
  type: 'success' | 'error' | 'info';
};