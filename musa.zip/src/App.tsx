import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from './components/ui/button';
import { TaskList } from './components/TaskList';
import { AddTaskModal } from './components/AddTaskModal';
import { ConfirmationDialog } from './components/ConfirmationDialog';
import { Snackbar } from './components/Snackbar';
import { Task, SnackbarMessage } from './types';
import { SNACKBAR_MESSAGES, generateId } from './utils/constants';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);
  const [snackbar, setSnackbar] = useState<SnackbarMessage | null>(null);

  const showSnackbar = (message: string, type: SnackbarMessage['type'] = 'success') => {
    setSnackbar({ message, type });
  };

  const handleAddTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: generateId(),
      createdAt: new Date(),
    };
    setTasks((prev) => [...prev, newTask]);
    showSnackbar(SNACKBAR_MESSAGES.TASK_ADDED);
  };

  const handleToggleComplete = (id: string) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
    
    const task = tasks.find(t => t.id === id);
    if (task) {
      showSnackbar(
        task.completed ? SNACKBAR_MESSAGES.TASK_UNCOMPLETED : SNACKBAR_MESSAGES.TASK_COMPLETED,
        'info'
      );
    }
  };

  const handleDeleteClick = (id: string) => {
    setTaskToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (taskToDelete) {
      setTasks((prev) => prev.filter((task) => task.id !== taskToDelete));
      showSnackbar(SNACKBAR_MESSAGES.TASK_DELETED);
      setTaskToDelete(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-4 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Task Manager</h1>
          <p className="text-sm text-gray-600 mt-1">
            {tasks.filter(t => !t.completed).length} active task{tasks.filter(t => !t.completed).length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Task List */}
      <div className="pb-20">
        <TaskList
          tasks={tasks}
          onToggleComplete={handleToggleComplete}
          onDelete={handleDeleteClick}
        />
      </div>

      {/* Floating Action Button */}
      <Button
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg flex items-center justify-center p-0"
        size="lg"
      >
        <Plus size={24} className="text-white" />
      </Button>

      {/* Add Task Modal */}
      <AddTaskModal
        open={isAddModalOpen}
        onOpenChange={setIsAddModalOpen}
        onAddTask={handleAddTask}
      />

      {/* Delete Confirmation Dialog */}
      <ConfirmationDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={handleDeleteConfirm}
        title="Delete Task"
        description="Are you sure you want to delete this task? This action cannot be undone."
      />

      {/* Snackbar */}
      <Snackbar
        message={snackbar}
        onClose={() => setSnackbar(null)}
      />
    </div>
  );
}