import { Trash2, Check } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Task } from '../types';
import { PRIORITY_OPTIONS } from '../utils/constants';

interface TaskCardProps {
  task: Task;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
}

export function TaskCard({ task, onToggleComplete, onDelete }: TaskCardProps) {
  const priorityColor = PRIORITY_OPTIONS.find(p => p.value === task.priority)?.color || '';
  
  return (
    <Card className={`mb-3 transition-all duration-200 ${task.completed ? 'opacity-60' : 'hover:shadow-md'}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onToggleComplete(task.id)}
            className={`mt-1 h-5 w-5 rounded-full p-0 flex-shrink-0 ${
              task.completed ? 'bg-green-600 border-green-600' : 'hover:bg-gray-100'
            }`}
          >
            {task.completed && <Check size={12} className="text-white" />}
          </Button>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className={`font-medium text-gray-900 truncate ${
                task.completed ? 'line-through' : ''
              }`}>
                {task.title}
              </h3>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${priorityColor}`}>
                {task.priority}
              </span>
            </div>
            
            {task.description && (
              <p className={`text-sm text-gray-600 ${
                task.completed ? 'line-through' : ''
              }`}>
                {task.description}
              </p>
            )}
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDelete(task.id)}
            className="text-red-600 hover:text-red-700 hover:bg-red-50 p-1"
          >
            <Trash2 size={16} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}