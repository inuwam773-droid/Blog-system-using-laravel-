import { useEffect } from 'react';
import { X } from 'lucide-react';
import { SnackbarMessage } from '../types';

interface SnackbarProps {
  message: SnackbarMessage | null;
  onClose: () => void;
}

export function Snackbar({ message, onClose }: SnackbarProps) {
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [message, onClose]);

  if (!message) return null;

  const bgColor = message.type === 'success' ? 'bg-green-600' : 
                  message.type === 'error' ? 'bg-red-600' : 'bg-blue-600';

  return (
    <div className={`fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 ${bgColor} text-white px-4 py-3 rounded-lg shadow-lg flex items-center justify-between z-50 animate-pulse`}>
      <span className="text-sm font-medium">{message.message}</span>
      <button
        onClick={onClose}
        className="ml-4 text-white hover:text-gray-200 transition-colors"
      >
        <X size={18} />
      </button>
    </div>
  );
}