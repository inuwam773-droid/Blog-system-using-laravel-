export const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low', color: 'bg-green-100 text-green-800' },
  { value: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'high', label: 'High', color: 'bg-red-100 text-red-800' },
] as const;

export const SNACKBAR_MESSAGES = {
  TASK_ADDED: 'Task added successfully!',
  TASK_DELETED: 'Task deleted successfully!',
  TITLE_REQUIRED: 'Title is required',
  TASK_COMPLETED: 'Task marked as completed',
  TASK_UNCOMPLETED: 'Task marked as incomplete',
} as const;

export const generateId = () => Math.random().toString(36).substr(2, 9);